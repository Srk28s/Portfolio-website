import React, { useState } from 'react';
import { Github, Linkedin, Mail, ExternalLink, Code2, Briefcase, User, ChevronDown, Edit2, Check } from 'lucide-react';
import ContentEditable from 'react-contenteditable';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  link: string;
}

interface Skill {
  id: number;
  name: string;
}

function App() {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState('Your Name');
  const [title, setTitle] = useState('Full Stack Developer | UI/UX Enthusiast | Problem Solver');
  const [about, setAbout] = useState(
    "I'm a passionate developer with expertise in building modern web applications. With a strong foundation in both frontend and backend technologies, I create elegant solutions to complex problems."
  );
  const [skills, setSkills] = useState<Skill[]>([
    { id: 1, name: 'React' },
    { id: 2, name: 'TypeScript' },
    { id: 3, name: 'Node.js' },
    { id: 4, name: 'Python' },
    { id: 5, name: 'SQL' },
    { id: 6, name: 'AWS' },
  ]);
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 1,
      title: 'Project Title 1',
      description: 'A brief description of the project and the technologies used.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
      link: '#'
    },
    {
      id: 2,
      title: 'Project Title 2',
      description: 'A brief description of the project and the technologies used.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
      link: '#'
    }
  ]);

  const handleContentChange = (setter: (value: string) => void) => (evt: any) => {
    setter(evt.target.value);
  };

  const handleSkillChange = (id: number) => (evt: any) => {
    setSkills(skills.map(skill => 
      skill.id === id ? { ...skill, name: evt.target.value } : skill
    ));
  };

  const handleProjectChange = (id: number, field: keyof Project) => (evt: any) => {
    setProjects(projects.map(project => 
      project.id === id ? { ...project, [field]: evt.target.value } : project
    ));
  };

  const addSkill = () => {
    const newId = Math.max(...skills.map(s => s.id)) + 1;
    setSkills([...skills, { id: newId, name: 'New Skill' }]);
  };

  const removeSkill = (id: number) => {
    setSkills(skills.filter(skill => skill.id !== id));
  };

  const addProject = () => {
    const newId = Math.max(...projects.map(p => p.id)) + 1;
    setProjects([...projects, {
      id: newId,
      title: 'New Project',
      description: 'Project description',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
      link: '#'
    }]);
  };

  const removeProject = (id: number) => {
    setProjects(projects.filter(project => project.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <button
        onClick={() => setIsEditing(!isEditing)}
        className="fixed top-4 right-4 z-50 bg-indigo-600 text-white p-2 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
      >
        {isEditing ? <Check size={24} /> : <Edit2 size={24} />}
      </button>

      {/* Hero Section */}
      <section className="min-h-screen flex flex-col justify-center relative px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-100 opacity-70"></div>
          <img
            src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80"
            alt="Background"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <h1 className="text-5xl sm:text-6xl font-bold text-gray-900 mb-6">
            Hi, I'm{' '}
            <ContentEditable
              html={name}
              disabled={!isEditing}
              onChange={handleContentChange(setName)}
              className="inline-block text-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
            />
          </h1>
          <ContentEditable
            html={title}
            disabled={!isEditing}
            onChange={handleContentChange(setTitle)}
            className="text-xl sm:text-2xl text-gray-700 mb-8 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
          />
          <div className="flex justify-center space-x-4 mb-12">
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Github size={24} />
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors">
              <Mail size={24} />
            </a>
          </div>
          <a href="#about" className="animate-bounce inline-block">
            <ChevronDown size={32} className="text-gray-600" />
          </a>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center mb-12">
            <User size={32} className="text-indigo-600 mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">About Me</h2>
          </div>
          <div className="prose prose-lg mx-auto">
            <ContentEditable
              html={about}
              disabled={!isEditing}
              onChange={handleContentChange(setAbout)}
              className="text-gray-600 text-center focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
            />
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center mb-12">
            <Code2 size={32} className="text-indigo-600 mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">Skills</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            {skills.map((skill) => (
              <div key={skill.id} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow relative">
                <ContentEditable
                  html={skill.name}
                  disabled={!isEditing}
                  onChange={handleSkillChange(skill.id)}
                  className="text-center text-gray-800 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
                />
                {isEditing && (
                  <button
                    onClick={() => removeSkill(skill.id)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full text-sm"
                  >
                    ×
                  </button>
                )}
              </div>
            ))}
            {isEditing && (
              <button
                onClick={addSkill}
                className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-500 hover:text-indigo-600"
              >
                Add Skill
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center mb-12">
            <Briefcase size={32} className="text-indigo-600 mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">Projects</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project) => (
              <div key={project.id} className="bg-gray-50 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow relative">
                {isEditing && (
                  <button
                    onClick={() => removeProject(project.id)}
                    className="absolute top-2 right-2 z-10 bg-red-500 text-white p-1 rounded-full text-sm"
                  >
                    ×
                  </button>
                )}
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <ContentEditable
                    html={project.title}
                    disabled={!isEditing}
                    onChange={handleProjectChange(project.id, 'title')}
                    className="text-xl font-bold text-gray-900 mb-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
                  />
                  <ContentEditable
                    html={project.description}
                    disabled={!isEditing}
                    onChange={handleProjectChange(project.id, 'description')}
                    className="text-gray-600 mb-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded px-1"
                  />
                  <a href={project.link} className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
                    View Project <ExternalLink size={16} className="ml-1" />
                  </a>
                </div>
              </div>
            ))}
            {isEditing && (
              <button
                onClick={addProject}
                className="bg-gray-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-500 hover:text-indigo-600 h-[300px]"
              >
                Add Project
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center mb-12">
            <Mail size={32} className="text-indigo-600 mr-3" />
            <h2 className="text-3xl font-bold text-gray-900">Contact</h2>
          </div>
          <div className="max-w-lg mx-auto">
            <form className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  id="name"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  id="email"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                <textarea
                  id="message"
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>© {new Date().getFullYear()} {name}. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;